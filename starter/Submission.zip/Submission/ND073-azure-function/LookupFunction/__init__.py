import logging
import json
import requests
import azure.functions as func

CROSSREF_API_ENDPOINT = "https://api.crossref.org/works"

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info("CrossrefLookup: Python HTTP trigger function processed a request.")

    try:
        data = req.get_json()
        logging.info(f"Received data: {json.dumps(data)}")
    except Exception as e:
        logging.error(f"Error parsing JSON: {e}")
        return func.HttpResponse(
            "Invalid JSON in request body.",
            status_code=400
        )

    # Handle both formats: direct call and Azure AI Search
    if "Values" in data and isinstance(data["Values"], list):
        # Standard format from manual testing
        response = {"Values": []}
        for record in data["Values"]:
            if record is None or "RecordId" not in record:
                continue

            response_record = {
                "RecordId": record["RecordId"],
                "Data": {},
                "Errors": [],
                "Warnings": []
            }

            try:
                article_name = record.get("Data", {}).get("ArticleName")
                if article_name:
                    response_record["Data"] = get_entity_metadata(article_name)
            except Exception as e:
                logging.error(f"Error while fetching Crossref metadata: {e}")
                response_record["Errors"].append({"Message": str(e)})
            finally:
                response["Values"].append(response_record)

        return func.HttpResponse(
            json.dumps(response),
            status_code=200,
            mimetype="application/json"
        )
    
    elif "values" in data and isinstance(data["values"], list):
        # Azure AI Search format (lowercase 'values')
        response = {"values": []}
        for record in data["values"]:
            if record is None or "recordId" not in record:
                continue

            response_record = {
                "recordId": record["recordId"],
                "data": {},
                "errors": [],
                "warnings": []
            }

            try:
                article_name = record.get("data", {}).get("ArticleName")
                if article_name:
                    metadata = get_entity_metadata(article_name)
                    response_record["data"] = metadata
                # Don't add warnings or errors unless critical
            except Exception as e:
                logging.error(f"Error while fetching Crossref metadata: {e}")
                # Only add error if it's critical, otherwise return empty data
                response_record["data"] = {
                    "PublicationName": "",
                    "Publisher": "",
                    "DOI": "",
                    "PublicationDate": ""
                }
            finally:
                response["values"].append(response_record)

        return func.HttpResponse(
            json.dumps(response),
            status_code=200,
            mimetype="application/json"
        )
    
    else:
        # Try to handle single record format
        logging.info("Trying single record format")
        try:
            article_name = data.get("ArticleName") or data.get("articleName")
            if article_name:
                metadata = get_entity_metadata(article_name)
                return func.HttpResponse(
                    json.dumps({"values": [{"recordId": "1", "data": metadata}]}),
                    status_code=200,
                    mimetype="application/json"
                )
        except Exception as e:
            logging.error(f"Error in single record handling: {e}")

        # If all else fails
        logging.error(f"Unrecognized request format: {json.dumps(data)}")
        return func.HttpResponse(
            json.dumps({
                "error": "The request schema does not match expected schema. Expected 'Values' or 'values' array.",
                "receivedData": data
            }),
            status_code=400,
            mimetype="application/json"
        )


def get_entity_metadata(title):
    """
    find an article by Crossref REST API and return metadata if there is exact match in title (case-insensitive).
    """
    result = {
        "PublicationName": "",
        "Publisher": "",
        "DOI": "",
        "PublicationDate": "1900-01-01T00:00:00Z"
    }

    # Handle both string and list inputs
    if isinstance(title, list):
        if len(title) > 0:
            title = str(title[0])  # Take first item and convert to string
        else:
            return result  # Return empty result for empty list
    elif not isinstance(title, str):
        title = str(title)  # Convert to string if it's something else

    # Skip if title is empty
    if not title.strip():
        return result

    params = {
        "query.title": title.strip(),
        "rows": 10
    }

    try:
        r = requests.get(CROSSREF_API_ENDPOINT, params=params)
        r.raise_for_status()
        data = r.json()

        items = data.get("message", {}).get("items", [])
        for item in items:
            item_title = " ".join(item.get("title", [])).strip()
            if item_title.lower() == title.lower():
                result["DOI"] = item.get("DOI", "")
                result["PublicationName"] = item_title
                result["Publisher"] = item.get("publisher", "")
                
                # Format publication date for Azure Search
                published_date = item.get("published-online") or item.get("published-print")
                if published_date and "date-parts" in published_date:
                    date_parts = published_date["date-parts"][0]
                    if len(date_parts) >= 3:
                        result["PublicationDate"] = f"{date_parts[0]:04d}-{date_parts[1]:02d}-{date_parts[2]:02d}T00:00:00Z"
                    elif len(date_parts) >= 2:
                        result["PublicationDate"] = f"{date_parts[0]:04d}-{date_parts[1]:02d}-01T00:00:00Z"
                    elif len(date_parts) >= 1:
                        result["PublicationDate"] = f"{date_parts[0]:04d}-01-01T00:00:00Z"
                break
                
    except Exception as e:
        logging.error(f"Error in get_entity_metadata: {e}")
        # Don't return errors in result, just log them

    if not result["PublicationDate"] or result["PublicationDate"] == "":
        result["PublicationDate"] = "1900-01-01T00:00:00Z"
        
    return result